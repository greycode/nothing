package com.bankcard.bininfo;

import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.util.Locale;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CardBrandTest {

    @Test
    void testCardBrandInterface() {
        CardBrand visa = CardBrands.VISA;
        assertEquals("Visa", visa.getName());
        assertEquals("visa", visa.getCode());
        assertEquals("card.brand.visa.desc", visa.getDescKey());
    }

    @Test
    void testGetDesc() {
        CardBrand mastercard = CardBrands.MASTERCARD;
        try (MockedStatic<I18nManager> mockedStatic = Mockito.mockStatic(I18nManager.class)) {
            I18nManager mockManager = mock(I18nManager.class);
            when(I18nManager.getInstance()).thenReturn(mockManager);
            when(mockManager.getString("card.brand.mastercard.desc")).thenReturn("Mastercard Description");

            assertEquals("Mastercard Description", mastercard.getDesc());
            verify(mockManager).getString("card.brand.mastercard.desc");
        }
    }

    @Test
    void testGetDescWithLocale() {
        CardBrand amex = CardBrands.AMEX;
        Locale locale = Locale.FRANCE;
        try (MockedStatic<I18nManager> mockedStatic = Mockito.mockStatic(I18nManager.class)) {
            when(I18nManager.getString("card.brand.amex.desc", locale)).thenReturn("American Express Description");

            assertEquals("American Express Description", amex.getDesc(locale));
            mockedStatic.verify(() -> I18nManager.getString("card.brand.amex.desc", locale));
        }
    }
}

class CardBrandsTest {

    @Test
    void testPredefinedCardBrands() {
        assertNotNull(CardBrands.VISA);
        assertNotNull(CardBrands.MASTERCARD);
        assertNotNull(CardBrands.AMEX);
        // ... test all other predefined card brands
    }

    @Test
    void testRegister() {
        CardBrand newBrand = new CardBrands.CardBrandImpl("New Brand", "newbrand");
        CardBrands.register(newBrand);
        assertEquals(newBrand, CardBrands.getByCode("newbrand"));
    }

    @Test
    void testRegisterFromJson() {
        String json = "{\"name\":\"JSON Brand\",\"code\":\"jsonbrand\"}";
        CardBrand jsonBrand = CardBrands.registerFromJson(json);
        assertNotNull(jsonBrand);
        assertEquals("JSON Brand", jsonBrand.getName());
        assertEquals("jsonbrand", jsonBrand.getCode());
        assertEquals(jsonBrand, CardBrands.getByCode("jsonbrand"));
    }

    @Test
    void testRegisterFromJsonInvalidFormat() {
        String invalidJson = "{invalid:json}";
        assertThrows(IllegalArgumentException.class, () -> CardBrands.registerFromJson(invalidJson));
    }

    @Test
    void testGetByCode() {
        assertEquals(CardBrands.VISA, CardBrands.getByCode("visa"));
        assertEquals(CardBrands.MASTERCARD, CardBrands.getByCode("mastercard"));
        assertNull(CardBrands.getByCode("nonexistent"));
    }

    @Test
    void testGetByCodeCaseInsensitive() {
        assertEquals(CardBrands.VISA, CardBrands.getByCode("VISA"));
        assertEquals(CardBrands.MASTERCARD, CardBrands.getByCode("MasterCard"));
    }
}