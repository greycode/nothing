package com.bankcard.serialization;

import com.bankcard.bininfo.BinInfo;
import com.bankcard.bininfo.CountryInfo;
import com.bankcard.bininfo.IssuerInfo;
import com.bankcard.core.*;
import com.bankcard.security.Encryptor;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class BankCardDeserializerTest {

    private BankCardDeserializer deserializer;
    private ObjectMapper objectMapper;

    @Mock
    private JsonParser jsonParser;

    @Mock
    private DeserializationContext context;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        deserializer = new BankCardDeserializer();
        objectMapper = new ObjectMapper();
    }

    @Test
    void testDeserialize() throws IOException {
        // Prepare test data
        String accountNumber = "1234567890123456";
        String expirationDate = Encryptor.encrypt("2025-12");
        String cardholderName = "John Doe";
        String serviceCode = "123";

        ObjectNode binInfoNode = objectMapper.createObjectNode();
        binInfoNode.put("isoCountryName", "United States");
        binInfoNode.put("isoCountryCodeA2", "US");
        binInfoNode.put("isoCountryCodeA3", "USA");
        binInfoNode.put("isoCountryCurrency", "USD");
        binInfoNode.put("issuerName", "Test Bank");
        binInfoNode.put("issuerShortName", "TB");
        binInfoNode.put("issuerWebsite", "www.testbank.com");
        binInfoNode.put("issuerPhone", "1234567890");

        ObjectNode rootNode = objectMapper.createObjectNode();
        rootNode.put("accountNumber", accountNumber);
        rootNode.put("expirationDate", expirationDate);
        rootNode.put("cardholderName", cardholderName);
        rootNode.put("serviceCode", serviceCode);
        rootNode.set("binInfo", binInfoNode);

        // Mock behavior
        when(jsonParser.getCodec()).thenReturn(objectMapper);
        when(jsonParser.readValueAsTree()).thenReturn(rootNode);

        // Perform deserialization
        BankCard result = deserializer.deserialize(jsonParser, context);

        // Verify results
        assertNotNull(result);
        assertEquals(accountNumber, result.getAccountNumber().getRawNumber());
        assertEquals(2025, result.getExpirationDate().getYear());
        assertEquals(12, result.getExpirationDate().getMonth());
        assertEquals("John", result.getCardholderName().getFirstName());
        assertEquals("Doe", result.getCardholderName().getLastName());
        assertEquals(serviceCode, result.getServiceCode().getCode());

        // Verify that the method was called
        verify(jsonParser, times(1)).getCodec();
        verify(jsonParser, times(1)).readValueAsTree();
    }

    @Test
    void testDeserializeWithInvalidData() {
        // Prepare invalid test data
        ObjectNode rootNode = objectMapper.createObjectNode();
        rootNode.put("accountNumber", "invalid");

        // Mock behavior
        when(jsonParser.getCodec()).thenReturn(objectMapper);
        when(jsonParser.readValueAsTree()).thenReturn(rootNode);

        // Perform deserialization and expect exception
        assertThrows(RuntimeException.class, () -> deserializer.deserialize(jsonParser, context));
    }
}