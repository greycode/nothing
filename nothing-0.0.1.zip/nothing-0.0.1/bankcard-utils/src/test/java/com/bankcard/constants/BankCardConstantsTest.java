package com.bankcard.constants;

import org.junit.jupiter.api.Test;
import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;

import static org.junit.jupiter.api.Assertions.*;

class BankCardConstantsTest {

    @Test
    void testConstantValues() {
        assertEquals("accountNumber", BankCardConstants.ACCOUNT_NUMBER);
        assertEquals("expirationDate", BankCardConstants.EXPIRATION_DATE);
        assertEquals("cardholderName", BankCardConstants.CARDHOLDER_NAME);
        assertEquals("serviceCode", BankCardConstants.SERVICE_CODE);
        assertEquals("binInfo", BankCardConstants.BIN_INFO);
        assertEquals("cardBrand", BankCardConstants.CARD_BRAND);
        assertEquals("cardType", BankCardConstants.CARD_TYPE);
        assertEquals("cardLevel", BankCardConstants.CARD_LEVEL);
        assertEquals("issuerName", BankCardConstants.ISSUER_NAME);
        assertEquals("issuerShortName", BankCardConstants.ISSUER_SHORT_NAME);
        assertEquals("issuerWebsite", BankCardConstants.ISSUER_WEBSITE);
        assertEquals("issuerPhone", BankCardConstants.ISSUER_PHONE);
        assertEquals("isoCountryName", BankCardConstants.ISO_COUNTRY_NAME);
        assertEquals("isoCountryCodeA2", BankCardConstants.ISO_COUNTRY_CODE_A2);
        assertEquals("isoCountryCodeA3", BankCardConstants.ISO_COUNTRY_CODE_A3);
        assertEquals("isoCountryCurrency", BankCardConstants.ISO_COUNTRY_CURRENCY);
    }

    @Test
    void testPrivateConstructor() throws Exception {
        Constructor<BankCardConstants> constructor = BankCardConstants.class.getDeclaredConstructor();
        assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);
        constructor.newInstance();
    }
}