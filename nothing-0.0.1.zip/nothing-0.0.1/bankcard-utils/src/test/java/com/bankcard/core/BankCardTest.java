package com.bankcard.core;

import com.bankcard.bininfo.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class BankCardTest {

    private BinInfoRepository mockRepository;

    @BeforeEach
    void setUp() {
        mockRepository = mock(BinInfoRepository.class);
    }

    @Test
    void testBankCardConstructor() {
        AccountNumber accountNumber = new AccountNumber("1234567890123456");
        ExpirationDate expirationDate = new ExpirationDate(2025, 12);
        Name cardholderName = new Name("John", "Doe");
        ServiceCode serviceCode = new ServiceCode("123");

        BinInfo mockBinInfo = mock(BinInfo.class);
        when(mockRepository.getBinInfo("1234567890123456")).thenReturn(mockBinInfo);

        try (MockedStatic<BinInfoRepository> mockedStatic = mockStatic(BinInfoRepository.class)) {
            mockedStatic.when(BinInfoRepository::getInstance).thenReturn(mockRepository);

            BankCard bankCard = new BankCard(accountNumber, expirationDate, cardholderName, serviceCode);

            assertEquals(accountNumber, bankCard.getAccountNumber());
            assertEquals(expirationDate, bankCard.getExpirationDate());
            assertEquals(cardholderName, bankCard.getCardholderName());
            assertEquals(serviceCode, bankCard.getServiceCode());
            assertEquals(mockBinInfo, bankCard.getBinInfo());
        }
    }

    @Test
    void testBankCardConstructorWithOnlyAccountNumber() {
        String accountNumber = "1234567890123456";
        BinInfo mockBinInfo = mock(BinInfo.class);
        when(mockRepository.getBinInfo(accountNumber)).thenReturn(mockBinInfo);

        try (MockedStatic<BinInfoRepository> mockedStatic = mockStatic(BinInfoRepository.class)) {
            mockedStatic.when(BinInfoRepository::getInstance).thenReturn(mockRepository);

            BankCard bankCard = new BankCard(accountNumber);

            assertEquals(accountNumber, bankCard.getAccountNumber().getRawNumber());
            assertNull(bankCard.getExpirationDate());
            assertNull(bankCard.getCardholderName());
            assertNull(bankCard.getServiceCode());
            assertEquals(mockBinInfo, bankCard.getBinInfo());
        }
    }

    @Test
    void testBankCardFrom() {
        String accountNumber = "1234567890123456";
        BinInfo mockBinInfo = mock(BinInfo.class);
        when(mockRepository.getBinInfo(accountNumber)).thenReturn(mockBinInfo);

        try (MockedStatic<BinInfoRepository> mockedStatic = mockStatic(BinInfoRepository.class)) {
            mockedStatic.when(BinInfoRepository::getInstance).thenReturn(mockRepository);

            BankCard bankCard = BankCard.from(accountNumber);

            assertEquals(accountNumber, bankCard.getAccountNumber().getRawNumber());
            assertNull(bankCard.getExpirationDate());
            assertNull(bankCard.getCardholderName());
            assertNull(bankCard.getServiceCode());
            assertEquals(mockBinInfo, bankCard.getBinInfo());
        }
    }

    @Test
    void testEquals() {
        BankCard card1 = new BankCard("1234567890123456");
        BankCard card2 = new BankCard("1234567890123456");
        BankCard card3 = new BankCard("9876543210987654");

        assertEquals(card1, card2);
        assertNotEquals(card1, card3);
    }

    @Test
    void testHashCode() {
        BankCard card1 = new BankCard("1234567890123456");
        BankCard card2 = new BankCard("1234567890123456");

        assertEquals(card1.hashCode(), card2.hashCode());
    }

    @Test
    void testToString() {
        BankCard bankCard = new BankCard("1234567890123456");
        String cardString = bankCard.toString();

        assertTrue(cardString.contains("BankCard"));
        assertTrue(cardString.contains("accountNumber"));
        assertFalse(cardString.contains("1234567890123456")); // Should be encrypted
    }
}