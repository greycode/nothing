package com.bankcard.bininfo;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BinInfoTest {

    @Test
    void testBinInfoBuilder() {
        IssuerInfo issuerInfo = new IssuerInfo("Test Bank", "TB", "www.testbank.com", "1234567890", 
                new CountryInfo("United States", "US", "USA", "USD"));

        BinInfo binInfo = new BinInfo.Builder("123456")
                .cardBrand(CardBrands.VISA)
                .cardType(CardType.CREDIT)
                .cardLevel(CardLevel.PLATINUM)
                .issuerInfo(issuerInfo)
                .build();

        assertEquals("123456", binInfo.getBin());
        assertEquals(CardBrands.VISA, binInfo.getCardBrand());
        assertEquals(CardType.CREDIT, binInfo.getCardType());
        assertEquals(CardLevel.PLATINUM, binInfo.getCardLevel());
        assertEquals(issuerInfo, binInfo.getIssuerInfo());
    }

    @Test
    void testBinInfoBuilderWithNullBin() {
        assertThrows(NullPointerException.class, () -> new BinInfo.Builder(null));
    }

    @Test
    void testEquals() {
        BinInfo binInfo1 = new BinInfo.Builder("123456").cardBrand(CardBrands.VISA).build();
        BinInfo binInfo2 = new BinInfo.Builder("123456").cardBrand(CardBrands.MASTERCARD).build();
        BinInfo binInfo3 = new BinInfo.Builder("654321").cardBrand(CardBrands.VISA).build();

        assertEquals(binInfo1, binInfo2);
        assertNotEquals(binInfo1, binInfo3);
    }

    @Test
    void testHashCode() {
        BinInfo binInfo1 = new BinInfo.Builder("123456").cardBrand(CardBrands.VISA).build();
        BinInfo binInfo2 = new BinInfo.Builder("123456").cardBrand(CardBrands.MASTERCARD).build();

        assertEquals(binInfo1.hashCode(), binInfo2.hashCode());
    }

    @Test
    void testToString() {
        BinInfo binInfo = new BinInfo.Builder("123456")
                .cardBrand(CardBrands.VISA)
                .cardType(CardType.CREDIT)
                .cardLevel(CardLevel.PLATINUM)
                .build();

        String binInfoString = binInfo.toString();

        assertTrue(binInfoString.contains("BinInfo"));
        assertTrue(binInfoString.contains("123456"));
        assertTrue(binInfoString.contains("VISA"));
        assertTrue(binInfoString.contains("CREDIT"));
        assertTrue(binInfoString.contains("PLATINUM"));
    }
}