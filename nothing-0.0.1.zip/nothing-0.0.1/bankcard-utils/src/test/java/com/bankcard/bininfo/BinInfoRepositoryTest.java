package com.bankcard.bininfo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

class BinInfoRepositoryTest {

    private BinInfoRepository repository;

    @BeforeEach
    void setUp() {
        repository = BinInfoRepository.getInstance(false); // Use in-memory storage
    }

    @AfterEach
    void tearDown() {
        // Clear all BIN info after each test
        for (BinInfo binInfo : repository.getAllBinInfo()) {
            repository.storage.removeBinInfo(binInfo.getBin());
        }
    }

    @Test
    void testSingleton() {
        BinInfoRepository anotherInstance = BinInfoRepository.getInstance(false);
        assertSame(repository, anotherInstance);
    }

    @Test
    void testAddAndGetBinInfo() {
        BinInfo binInfo = new BinInfo.Builder("123456")
                .cardBrand(CardBrands.VISA)
                .cardType(CardType.CREDIT)
                .cardLevel(CardLevel.PLATINUM)
                .issuerInfo(new IssuerInfo("Test Bank", "www.testbank.com", "1234567890", "TB", 
                        new CountryInfo("US", "USA", "United States", "840")))
                .build();

        repository.addBinInfo(binInfo);

        BinInfo retrievedInfo = repository.getBinInfo("123456789012345");
        assertNotNull(retrievedInfo);
        assertEquals(binInfo, retrievedInfo);
    }

    @Test
    void testGetBinInfoWithNonExistentBin() {
        BinInfo retrievedInfo = repository.getBinInfo("999999999999999");
        assertNull(retrievedInfo);
    }

    @Test
    void testConcurrentAccess() throws InterruptedException {
        int threadCount = 100;
        Thread[] threads = new Thread[threadCount];
        
        for (int i = 0; i < threadCount; i++) {
            final String bin = String.format("%06d", i);
            threads[i] = new Thread(() -> {
                BinInfo binInfo = new BinInfo.Builder(bin)
                        .cardBrand(CardBrands.VISA)
                        .build();
                repository.addBinInfo(binInfo);
                BinInfo retrieved = repository.getBinInfo(bin + "0000000000");
                assertNotNull(retrieved);
                assertEquals(bin, retrieved.getBin());
            });
            threads[i].start();
        }

        for (Thread thread : threads) {
            thread.join();
        }
    }

    @Test
    void testUpdateBinInfo() {
        BinInfo originalBinInfo = new BinInfo.Builder("654321")
                .cardBrand(CardBrands.MASTERCARD)
                .build();
        repository.addBinInfo(originalBinInfo);

        BinInfo updatedBinInfo = new BinInfo.Builder("654321")
                .cardBrand(CardBrands.VISA)
                .build();
        repository.updateBinInfo(updatedBinInfo);

        BinInfo retrievedInfo = repository.getBinInfo("654321000000000");
        assertNotNull(retrievedInfo);
        assertEquals(CardBrands.VISA, retrievedInfo.getCardBrand());
    }

    @Test
    void testGetAllBinInfo() {
        BinInfo binInfo1 = new BinInfo.Builder("111111").cardBrand(CardBrands.VISA).build();
        BinInfo binInfo2 = new BinInfo.Builder("222222").cardBrand(CardBrands.MASTERCARD).build();
        
        repository.addBinInfo(binInfo1);
        repository.addBinInfo(binInfo2);

        List<BinInfo> allBinInfo = repository.getAllBinInfo();
        assertEquals(2, allBinInfo.size());
        assertTrue(allBinInfo.contains(binInfo1));
        assertTrue(allBinInfo.contains(binInfo2));
    }

    @Test
    void testQuickMatch() {
        // Test the quick match functionality
        BinInfo retrievedInfo = repository.getBinInfo("6221260000000000");
        assertNotNull(retrievedInfo);
        assertEquals(CardBrands.DISCOVER, retrievedInfo.getCardBrand());

        retrievedInfo = repository.getBinInfo("6040010000000000");
        assertNotNull(retrievedInfo);
        assertEquals(CardBrands.UKRCARD, retrievedInfo.getCardBrand());

        retrievedInfo = repository.getBinInfo("5060990000000000");
        assertNotNull(retrievedInfo);
        assertEquals(CardBrands.VERVE, retrievedInfo.getCardBrand());
    }

    @Test
    void testUpdateQuickMatchData() {
        String jsonData = "{\"4\":\"VISA\",\"51-55\":\"MASTERCARD\"}";
        BinInfoRepository.updateQuickMatchData(jsonData);

        BinInfo retrievedInfo = repository.getBinInfo("4111111111111111");
        assertNotNull(retrievedInfo);
        assertEquals(CardBrands.VISA, retrievedInfo.getCardBrand());

        retrievedInfo = repository.getBinInfo("5412345678901234");
        assertNotNull(retrievedInfo);
        assertEquals(CardBrands.MASTERCARD, retrievedInfo.getCardBrand());
    }
}