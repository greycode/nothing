package com.bankcard.perf;


import com.bankcard.bininfo.BinInfo;
import com.bankcard.bininfo.BinInfoRepository;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

public class ConcurrentCardMatcher {
    private static final int THREAD_POOL_SIZE = Runtime.getRuntime().availableProcessors();
    private static final ExecutorService executorService = Executors.newFixedThreadPool(THREAD_POOL_SIZE);

    public static List<BinInfo> matchCards(List<String> cardNumbers) {
        List<CompletableFuture<BinInfo>> futures = cardNumbers.stream()
                .map(cardNumber -> CompletableFuture.supplyAsync(() ->
                        BinInfoRepository.getInstance().getBinInfo(cardNumber), executorService))
                .collect(Collectors.toList());

        return futures.stream()
                .map(CompletableFuture::join)
                .collect(Collectors.toList());
    }

    public static List<BinInfo> matchCards(List<String> cardNumbers, ExecutorService customExecutorService) {
        List<CompletableFuture<BinInfo>> futures = cardNumbers.stream()
                .map(cardNumber -> CompletableFuture.supplyAsync(() ->
                        BinInfoRepository.getInstance().getBinInfo(cardNumber), customExecutorService))
                .collect(Collectors.toList());

        return futures.stream()
                .map(CompletableFuture::join)
                .collect(Collectors.toList());
    }

    public static void shutdown() {
        executorService.shutdown();
    }
}