// src/main/java/com/bankcard/core/BankCard.java
package com.bankcard.core;

import com.bankcard.bininfo.BinInfo;
import com.bankcard.bininfo.BinInfoRepository;

import java.util.Objects;
import com.bankcard.security.Encryptor;

public final class BankCard {
    private final AccountNumber accountNumber;
    private final ExpirationDate expirationDate;
    private final Name cardholderName;
    private final ServiceCode serviceCode;
    private final BinInfo binInfo;

    public BankCard(AccountNumber accountNumber, ExpirationDate expirationDate, Name cardholderName, ServiceCode serviceCode) {
        this.accountNumber = Objects.requireNonNull(accountNumber, "Account number cannot be null");
        this.expirationDate = expirationDate;
        this.cardholderName = cardholderName;
        this.serviceCode = serviceCode;
        this.binInfo = BinInfoRepository.getInstance().getBinInfo(accountNumber.getRawNumber());
    }

    public BankCard(String accountNumber) {
        this(
            new AccountNumber(accountNumber),
            null,
            null,
            null
        );
    }

    public static BankCard from(String accountNumber) {
        return new BankCard(accountNumber);
    }

    public AccountNumber getAccountNumber() {
        return accountNumber;
    }

    public ExpirationDate getExpirationDate() {
        return expirationDate;
    }

    public Name getCardholderName() {
        return cardholderName;
    }

    public ServiceCode getServiceCode() {
        return serviceCode;
    }

    public BinInfo getBinInfo() {
        return binInfo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BankCard bankCard = (BankCard) o;
        return accountNumber.equals(bankCard.accountNumber) &&
                Objects.equals(expirationDate, bankCard.expirationDate) &&
                Objects.equals(cardholderName, bankCard.cardholderName) &&
                Objects.equals(serviceCode, bankCard.serviceCode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(accountNumber, expirationDate, cardholderName, serviceCode);
    }

    @Override
    public String toString() {
        return "BankCard{" +
                "accountNumber=" + Encryptor.encrypt(accountNumber.toString()) +
                ", expirationDate=" + (expirationDate != null ? expirationDate : "N/A") +
                ", cardholderName=" + (cardholderName != null ? Encryptor.encrypt(cardholderName.toString()) : "N/A") +
                ", serviceCode=" + (serviceCode != null ? serviceCode : "N/A") +
                ", binInfo=" + binInfo +
                '}';
    }

}