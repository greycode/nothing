package com.bankcard.bininfo;

public enum CardBrand {
    VISA, MASTERCARD, AMERICAN_EXPRESS, DISCOVER, JCB, DINERS_CLUB, UNKNOWN
}