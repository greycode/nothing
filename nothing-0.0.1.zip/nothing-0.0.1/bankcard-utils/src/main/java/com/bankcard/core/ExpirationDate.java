package com.bankcard.core;

import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public final class ExpirationDate {
    private final YearMonth date;


    
    public ExpirationDate(int year, int month) {
        this.date = YearMonth.of(year, month);
    }

    public boolean isExpired() {
        return date.isBefore(YearMonth.now());
    }

    public int getYear() {
        return date.getYear();
    }

    public int getMonth() {
        return date.getMonthValue();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ExpirationDate that = (ExpirationDate) o;
        return date.equals(that.date);
    }

    @Override
    public int hashCode() {
        return Objects.hash(date);
    }

    @Override
    public String toString() {
        return date.format(DateTimeFormatter.ofPattern("yyyy-MM"));
    }
}