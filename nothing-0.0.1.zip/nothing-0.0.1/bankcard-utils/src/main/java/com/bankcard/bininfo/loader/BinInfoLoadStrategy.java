package com.bankcard.bininfo.loader;

import java.io.InputStream;
import java.util.List;

public interface BinInfoLoadStrategy {
    List<BinInfo> loadBinInfo(InputStream inputStream) throws Exception;
}