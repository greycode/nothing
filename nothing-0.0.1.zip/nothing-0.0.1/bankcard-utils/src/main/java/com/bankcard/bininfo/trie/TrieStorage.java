package com.bankcard.bininfo.trie;

public interface TrieStorage {
    void insertIntoTrie(String bin);
    String findLongestMatch(String accountNumber);
}