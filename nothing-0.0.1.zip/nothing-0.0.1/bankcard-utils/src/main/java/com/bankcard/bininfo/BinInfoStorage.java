package com.bankcard.bininfo;

import java.util.List;

public interface BinInfoStorage {
    void addBinInfo(BinInfo binInfo);
    BinInfo getBinInfo(String bin);
    void updateBinInfo(BinInfo binInfo);
    List<BinInfo> getAllBinInfo();
}