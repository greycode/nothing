package com.bankcard.bininfo;

public enum CardType {
    CREDIT, DEBIT, PREPAID, UNKNOWN
}