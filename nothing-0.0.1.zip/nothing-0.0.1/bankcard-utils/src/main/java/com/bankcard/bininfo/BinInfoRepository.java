package com.bankcard.bininfo;

import com.bankcard.bininfo.storage.BinInfoStorage;
import com.bankcard.bininfo.storage.MemoryBinInfoStorage;
import com.bankcard.bininfo.storage.RedisBinInfoStorage;
import com.bankcard.bininfo.trie.TrieStorage;
import com.bankcard.bininfo.trie.MemoryTrieStorage;
import com.bankcard.bininfo.trie.RedisTrieStorage;
import com.bankcard.bininfo.util.RedisClient;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * BinInfoRepository is a singleton class responsible for managing and retrieving BIN (Bank Identification Number) information.
 * It provides efficient storage and lookup of BIN data using a combination of concurrent hash maps and a trie data structure.
 * 
 * <p>This repository is thread-safe and optimized for high-concurrency scenarios, utilizing {@link ConcurrentHashMap}
 * for fast lookups and a custom trie implementation with {@link StampedLock} for efficient prefix matching.</p>
 * 
 * <p><strong>Usage:</strong></p>
 * <ul>
 *   <li>Use {@link #getInstance()} to get the singleton instance of this repository.</li>
 *   <li>Use {@link #addBinInfo(BinInfo)} to add new BIN information to the repository.</li>
 *   <li>Use {@link #getBinInfo(String)} to retrieve BIN information for a given account number.</li>
 * </ul>
 * 
 * <p><strong>Note:</strong> This class is designed to be used as a singleton. Do not attempt to create instances
 * directly using the constructor.</p>
 * 
 * <p><strong>Example usage:</strong></p>
 * <pre>
 * {@code
 * // Get the singleton instance
 * BinInfoRepository repository = BinInfoRepository.getInstance();
 * 
 * // Add BIN information
 * BinInfo binInfo = new BinInfo.Builder("123456")
 *     .cardBrand(CardBrand.VISA)
 *     .cardType(CardType.CREDIT)
 *     .cardLevel(CardLevel.PLATINUM)
 *     .issuerInfo(new IssuerInfo("Bank Name", "Bank URL", "Bank Phone", "Bank Short Name", new CountryInfo("US", "USA", "United States", "840")))
 *     .build();
 * repository.addBinInfo(binInfo);
 * 
 * // Retrieve BIN information
 * String accountNumber = "1234567890123456";
 * BinInfo retrievedBinInfo = repository.getBinInfo(accountNumber);
 * if (retrievedBinInfo != null) {
 *     System.out.println("Card Brand: " + retrievedBinInfo.getCardBrand());
 *     System.out.println("Issuer: " + retrievedBinInfo.getIssuerInfo().getIssuerName());
 * } else {
 *     System.out.println("No BIN information found for this account number.");
 * }
 * }
 * </pre>
 * 
 * @see BinInfo
 * @see IssuerInfo
 * @see CardBrand
 * @see CardType
 * @see CardLevel
 */
public class BinInfoRepository {
    private static BinInfoRepository INSTANCE;
    private final BinInfoStorage storage;
    private final TrieStorage trieStorage;
    private static final CopyOnWriteArrayList<BinRange> quickMatchRanges = new CopyOnWriteArrayList<>();

    static {
        loadInitialQuickMatchData();
    }

    private BinInfoRepository(boolean useRedis) {
        if (useRedis) {
            RedisClient redisClient = new RedisClient();
            this.storage = new RedisBinInfoStorage(redisClient);
            this.trieStorage = new RedisTrieStorage(redisClient);
        } else {
            this.storage = new MemoryBinInfoStorage();
            this.trieStorage = new MemoryTrieStorage();
        }
    }

    public static synchronized BinInfoRepository getInstance(boolean useRedis) {
        if (INSTANCE == null) {
            INSTANCE = new BinInfoRepository(useRedis);
        }
        return INSTANCE;
    }

    public static BinInfoRepository getInstance() {
        return getInstance(false);
    }

    public void addBinInfo(BinInfo binInfo) {
        storage.addBinInfo(binInfo);
        trieStorage.insertIntoTrie(binInfo.getBin());
    }

    public BinInfo getBinInfo(String accountNumber) {
        // Try quick match first
        for (BinRange range : quickMatchRanges) {
            if (range.matches(accountNumber)) {
                return range.getBinInfo();
            }
        }

        // If quick match fails, use existing trie-based lookup
        String matchedBin = trieStorage.findLongestMatch(accountNumber);
        if (matchedBin != null) {
            return storage.getBinInfo(matchedBin);
        }
        return null;
    }

    public void updateBinInfo(BinInfo binInfo) {
        storage.updateBinInfo(binInfo);
    }

    public List<BinInfo> getAllBinInfo() {
        return storage.getAllBinInfo();
    }

    // Add method to dynamically update quick match data
    public static void updateQuickMatchData(String jsonString) {
        loadQuickMatchDataFromJson(jsonString);
    }

    private static void loadInitialQuickMatchData() {
        // Load hardcoded data
        addQuickMatchRange("622126-622925", new BinInfo.Builder("622126")
            .cardBrand(CardBrand.DISCOVER)
            .build());
        addQuickMatchRange("60400100-60420099", new BinInfo.Builder("60400100")
            .cardBrand(CardBrand.UKRCARD)
            .build());

        // Load data for Verve
        addQuickMatchRanges(Arrays.asList("506099-506198", "650002-650027", "507865-507964"), 
            new BinInfo.Builder("506099").cardBrand(CardBrand.VERVE).build());

        // Load data for GPN
        addQuickMatchRanges(Arrays.asList("50", "56", "58", "60-63"), 
            new BinInfo.Builder("50").cardBrand(CardBrand.GPN).build());

        // Load data from JSON string (example)
        // String jsonData = "{\"51-55,58,60-62\":\"MasterCard\",\"4\":\"Visa\"}";
        // loadQuickMatchDataFromJson(jsonData);
    }

    private static void addQuickMatchRanges(List<String> ranges, BinInfo binInfo) {
        for (String range : ranges) {
            addQuickMatchRange(range, binInfo);
        }
    }

    private static void addQuickMatchRange(String range, BinInfo binInfo) {
        String[] parts = range.split("-");
        String start = parts[0];
        String end = parts.length > 1 ? parts[1] : start;
        quickMatchRanges.add(new BinRange(start, end, binInfo));
    }

    private static void loadQuickMatchDataFromJson(String jsonString) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            Map<String, String> jsonData = mapper.readValue(jsonString, new TypeReference<Map<String, String>>() {});
            for (Map.Entry<String, String> entry : jsonData.entrySet()) {
                String ranges = entry.getKey();
                String cardBrand = entry.getValue();
                for (String range : ranges.split(",")) {
                    addQuickMatchRange(range, new BinInfo.Builder(range.split("-")[0])
                        .cardBrand(CardBrand.valueOf(cardBrand.toUpperCase()))
                        .build());
                }
            }
        } catch (Exception e) {
            // Log error or handle exception
        }
    }

    private static class BinRange {
        private final String start;
        private final String end;
        private final BinInfo binInfo;

        BinRange(String start, String end, BinInfo binInfo) {
            this.start = start;
            this.end = end;
            this.binInfo = binInfo;
        }

        boolean matches(String accountNumber) {
            int compareLength = Math.min(Math.min(start.length(), end.length()), accountNumber.length());
            String truncatedAccountNumber = accountNumber.substring(0, compareLength);
            return truncatedAccountNumber.compareTo(start.substring(0, compareLength)) >= 0 &&
                   truncatedAccountNumber.compareTo(end.substring(0, compareLength)) <= 0;
        }

        BinInfo getBinInfo() {
            return binInfo;
        }
    }
}