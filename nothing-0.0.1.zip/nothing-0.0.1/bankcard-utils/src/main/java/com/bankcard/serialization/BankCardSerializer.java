package com.bankcard.serialization;

import com.bankcard.constants.BankCardConstants;
import com.bankcard.core.BankCard;
import com.bankcard.security.Encryptor;
import com.bankcard.security.MaskingUtil;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;

public class BankCardSerializer extends StdSerializer<BankCard> {

    public BankCardSerializer() {
        this(null);
    }

    public BankCardSerializer(Class<BankCard> t) {
        super(t);
    }

    @Override
    public void serialize(BankCard bankCard, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
        jsonGenerator.writeStartObject();
        jsonGenerator.writeStringField(BankCardConstants.ACCOUNT_NUMBER, MaskingUtil.maskCardNumber(bankCard.getAccountNumber().getRawNumber()));
        jsonGenerator.writeStringField(BankCardConstants.EXPIRATION_DATE, Encryptor.encrypt(bankCard.getExpirationDate().toString()));
        jsonGenerator.writeStringField(BankCardConstants.CARDHOLDER_NAME, MaskingUtil.maskName(bankCard.getCardholderName().getFullName()));
        jsonGenerator.writeStringField(BankCardConstants.SERVICE_CODE, bankCard.getServiceCode().getCode());

        // Serialize BinInfo
        jsonGenerator.writeObjectFieldStart(BankCardConstants.BIN_INFO);
        jsonGenerator.writeStringField(BankCardConstants.CARD_BRAND, bankCard.getBinInfo().getCardBrand().getName());
        jsonGenerator.writeStringField(BankCardConstants.CARD_TYPE, bankCard.getBinInfo().getCardType().name());
        jsonGenerator.writeStringField(BankCardConstants.CARD_LEVEL, bankCard.getBinInfo().getCardLevel().name());
        jsonGenerator.writeStringField(BankCardConstants.ISSUER_NAME, bankCard.getBinInfo().getIssuerInfo().getIssuerName());
        jsonGenerator.writeStringField(BankCardConstants.ISSUER_SHORT_NAME, bankCard.getBinInfo().getIssuerInfo().getIssuerShortName());
        jsonGenerator.writeStringField(BankCardConstants.ISSUER_WEBSITE, bankCard.getBinInfo().getIssuerInfo().getIssuerWebsite());
        jsonGenerator.writeStringField(BankCardConstants.ISSUER_PHONE, bankCard.getBinInfo().getIssuerInfo().getIssuerPhone());
        jsonGenerator.writeStringField(BankCardConstants.ISO_COUNTRY_NAME, bankCard.getBinInfo().getIssuerInfo().getCountryInfo().getIsoCountryName());
        jsonGenerator.writeStringField(BankCardConstants.ISO_COUNTRY_CODE_A2, bankCard.getBinInfo().getIssuerInfo().getCountryInfo().getIsoCountryCodeA2());
        jsonGenerator.writeStringField(BankCardConstants.ISO_COUNTRY_CODE_A3, bankCard.getBinInfo().getIssuerInfo().getCountryInfo().getIsoCountryCodeA3());
        jsonGenerator.writeStringField(BankCardConstants.ISO_COUNTRY_CURRENCY, bankCard.getBinInfo().getIssuerInfo().getCountryInfo().getIsoCountryCurrency());
        jsonGenerator.writeEndObject();

        jsonGenerator.writeEndObject();
    }
}