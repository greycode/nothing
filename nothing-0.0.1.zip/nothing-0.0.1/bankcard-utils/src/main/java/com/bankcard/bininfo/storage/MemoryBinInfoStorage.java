package com.bankcard.bininfo.storage;

import com.bankcard.bininfo.BinInfo;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class MemoryBinInfoStorage implements BinInfoStorage {
    private final ConcurrentMap<String, BinInfo> binInfoMap = new ConcurrentHashMap<>();

    @Override
    public void addBinInfo(BinInfo binInfo) {
        binInfoMap.put(binInfo.getBin(), binInfo);
    }

    @Override
    public BinInfo getBinInfo(String bin) {
        return binInfoMap.get(bin);
    }

    @Override
    public void updateBinInfo(BinInfo binInfo) {
        binInfoMap.put(binInfo.getBin(), binInfo);
    }

    @Override
    public List<BinInfo> getAllBinInfo() {
        return new ArrayList<>(binInfoMap.values());
    }
}