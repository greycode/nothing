package com.bankcard.bininfo.loader;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class CsvBinInfoLoadStrategy implements BinInfoLoadStrategy {
    @Override
    public List<BinInfo> loadBinInfo(InputStream inputStream) throws IOException, CsvValidationException {
        List<BinInfo> binInfoList = new ArrayList<>();
        try (CSVReader reader = new CSVReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
            // Skip header
            reader.readNext();

            String[] line;
            while ((line = reader.readNext()) != null) {
                if (line.length == 12) { // Updated to include issuerShortName
                    CountryInfo countryInfo = new CountryInfo(line[7], line[8], line[9], line[10]);
                    IssuerInfo issuerInfo = new IssuerInfo(line[4], line[5], line[6], line[11], countryInfo);
                    BinInfo binInfo = new BinInfo.Builder(line[0])
                            .cardBrand(CardBrand.valueOf(line[1].toUpperCase()))
                            .cardType(CardType.valueOf(line[2].toUpperCase()))
                            .cardLevel(CardLevel.valueOf(line[3].toUpperCase()))
                            .issuerInfo(issuerInfo)
                            .build();
                    binInfoList.add(binInfo);
                }
            }
        }
        return binInfoList;
    }
}