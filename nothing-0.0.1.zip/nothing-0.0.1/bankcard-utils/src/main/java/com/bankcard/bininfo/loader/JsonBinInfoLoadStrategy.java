package com.bankcard.bininfo.loader;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class JsonBinInfoLoadStrategy implements BinInfoLoadStrategy {
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public List<BinInfo> loadBinInfo(InputStream inputStream) throws IOException {
        return objectMapper.readValue(inputStream, new TypeReference<List<BinInfo>>() {});
    }
}