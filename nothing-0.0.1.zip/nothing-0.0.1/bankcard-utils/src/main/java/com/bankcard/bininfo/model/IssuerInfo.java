package com.bankcard.bininfo;

import java.util.Objects;

public final class IssuerInfo {
    private final String issuerName;
    private final String issuerShortName;
    private final String issuerWebsite;
    private final String issuerPhone;
    private final CountryInfo countryInfo;

    public IssuerInfo(String issuerName, String issuerShortName, String issuerWebsite, String issuerPhone, CountryInfo countryInfo) {
        this.issuerName = issuerName;
        this.issuerShortName = issuerShortName;
        this.issuerWebsite = issuerWebsite;
        this.issuerPhone = issuerPhone;
        this.countryInfo = countryInfo;
    }

    public String getIssuerName() {
        return issuerName;
    }

    public String getIssuerShortName() {
        return issuerShortName;
    }

    public String getIssuerWebsite() {
        return issuerWebsite;
    }

    public String getIssuerPhone() {
        return issuerPhone;
    }

    public CountryInfo getCountryInfo() {
        return countryInfo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        IssuerInfo that = (IssuerInfo) o;
        return Objects.equals(issuerName, that.issuerName) &&
                Objects.equals(countryInfo, that.countryInfo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(issuerName, countryInfo);
    }

    @Override
    public String toString() {
        return "IssuerInfo{" +
                "issuerName='" + issuerName + '\'' +
                ", issuerShortName='" + issuerShortName + '\'' +
                ", issuerWebsite='" + issuerWebsite + '\'' +
                ", issuerPhone='" + issuerPhone + '\'' +
                ", countryInfo=" + countryInfo +
                '}';
    }
}