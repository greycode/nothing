// src/main/java/com/bankcard/serialization/BankCardDeserializer.java
package com.bankcard.serialization;

import com.bankcard.bininfo.CountryInfo;
import com.bankcard.bininfo.IssuerInfo;
import com.bankcard.constants.BankCardConstants;
import com.bankcard.core.*;
import com.bankcard.security.Encryptor;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import java.io.IOException;

public class BankCardDeserializer extends StdDeserializer<BankCard> {

    public BankCardDeserializer() {
        this(null);
    }

    public BankCardDeserializer(Class<?> vc) {
        super(vc);
    }

    @Override
    public BankCard deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException {
        JsonNode node = jp.getCodec().readTree(jp);

        String accountNumber = node.get(BankCardConstants.ACCOUNT_NUMBER).asText();
        String expirationDateEncrypted = node.get(BankCardConstants.EXPIRATION_DATE).asText();
        String cardholderName = node.get(BankCardConstants.CARDHOLDER_NAME).asText();
        String serviceCode = node.get(BankCardConstants.SERVICE_CODE).asText();

        // Decrypt expiration date
        String expirationDateDecrypted = Encryptor.decrypt(expirationDateEncrypted);
        String[] expirationParts = expirationDateDecrypted.split("-");
        ExpirationDate expirationDate = new ExpirationDate(Integer.parseInt(expirationParts[0]), Integer.parseInt(expirationParts[1]));

        // Parse name
        String[] nameParts = cardholderName.split(" ");
        Name name = new Name(nameParts[0], nameParts[1]);

        // Parse BinInfo
        JsonNode binInfoNode = node.get(BankCardConstants.BIN_INFO);
        CountryInfo countryInfo = new CountryInfo(
                binInfoNode.get(BankCardConstants.ISO_COUNTRY_NAME).asText(),
                binInfoNode.get(BankCardConstants.ISO_COUNTRY_CODE_A2).asText(),
                binInfoNode.get(BankCardConstants.ISO_COUNTRY_CODE_A3).asText(),
                binInfoNode.get(BankCardConstants.ISO_COUNTRY_CURRENCY).asText()
        );
        IssuerInfo issuerInfo = new IssuerInfo(
                binInfoNode.get(BankCardConstants.ISSUER_NAME).asText(),
                binInfoNode.get(BankCardConstants.ISSUER_SHORT_NAME).asText(),
                binInfoNode.get(BankCardConstants.ISSUER_WEBSITE).asText(),
                binInfoNode.get(BankCardConstants.ISSUER_PHONE).asText(),
                countryInfo
        );

        // Create BankCard object
        return new BankCard(
                new AccountNumber(accountNumber),
                expirationDate,
                name,
                new ServiceCode(serviceCode)
        );
    }
}