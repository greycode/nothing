package com.bankcard.bininfo;

import java.util.Objects;

public class CountryInfo {
    private final String isoCountryName;
    private final String isoCountryCodeA2;
    private final String isoCountryCodeA3;
    private final String isoCountryCurrency;

    public CountryInfo(String isoCountryName, String isoCountryCodeA2, String isoCountryCodeA3, String isoCountryCurrency) {
        this.isoCountryName = isoCountryName;
        this.isoCountryCodeA2 = isoCountryCodeA2;
        this.isoCountryCodeA3 = isoCountryCodeA3;
        this.isoCountryCurrency = isoCountryCurrency;
    }

    public String getIsoCountryName() {
        return isoCountryName;
    }

    public String getIsoCountryCodeA2() {
        return isoCountryCodeA2;
    }

    public String getIsoCountryCodeA3() {
        return isoCountryCodeA3;
    }

    public String getIsoCountryCurrency() {
        return isoCountryCurrency;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CountryInfo that = (CountryInfo) o;
        return Objects.equals(isoCountryCodeA2, that.isoCountryCodeA2);
    }

    @Override
    public int hashCode() {
        return Objects.hash(isoCountryCodeA2);
    }

    @Override
    public String toString() {
        return "CountryInfo{" +
                "isoCountryName='" + isoCountryName + '\'' +
                ", isoCountryCodeA2='" + isoCountryCodeA2 + '\'' +
                ", isoCountryCodeA3='" + isoCountryCodeA3 + '\'' +
                ", isoCountryCurrency='" + isoCountryCurrency + '\'' +
                '}';
    }
}