package com.bankcard.validation;

import com.bankcard.core.AccountNumber;
import com.bankcard.core.ExpirationDate;

import java.time.YearMonth;

public class CardValidator {

    private CardValidator() {
        // Private constructor to prevent instantiation
    }

    public static boolean isValidAccountNumber(String accountNumber) {
        return LuhnValidator.isValid(accountNumber);
    }

    public static boolean isValidExpirationDate(ExpirationDate expirationDate) {
        YearMonth currentDate = YearMonth.now();
        YearMonth cardExpiration = YearMonth.of(expirationDate.getYear(), expirationDate.getMonth());
        return !cardExpiration.isBefore(currentDate);
    }

    public static boolean isValidCardLength(AccountNumber accountNumber) {
        int length = accountNumber.getRawNumber().length();
        return length >= 13 && length <= 19; // Most card numbers are between 13 and 19 digits
    }

    public static boolean isValidCard(AccountNumber accountNumber, ExpirationDate expirationDate) {
        return isValidAccountNumber(accountNumber.getRawNumber()) &&
                isValidExpirationDate(expirationDate) &&
                isValidCardLength(accountNumber);
    }
}