package com.bankcard.core;

import java.util.Objects;

public final class ServiceCode {
    private final String code;

    public ServiceCode(String code) {
        if (code == null || code.length() != 3 || !code.matches("\\d{3}")) {
            throw new IllegalArgumentException("Service code must be a 3-digit string");
        }
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ServiceCode that = (ServiceCode) o;
        return code.equals(that.code);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code);
    }

    @Override
    public String toString() {
        return code;
    }
}