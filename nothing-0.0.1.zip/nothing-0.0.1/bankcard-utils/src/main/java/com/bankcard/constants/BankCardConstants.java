package com.bankcard.constants;

public final class BankCardConstants {
    // Common fields
    public static final String ACCOUNT_NUMBER = "accountNumber";
    public static final String EXPIRATION_DATE = "expirationDate";
    public static final String CARDHOLDER_NAME = "cardholderName";
    public static final String SERVICE_CODE = "serviceCode";
    public static final String BIN_INFO = "binInfo";

    // BinInfo fields
    public static final String CARD_BRAND = "cardBrand";
    public static final String CARD_TYPE = "cardType";
    public static final String CARD_LEVEL = "cardLevel";
    public static final String ISSUER_NAME = "issuerName";
    public static final String ISSUER_SHORT_NAME = "issuerShortName";
    public static final String ISSUER_WEBSITE = "issuerWebsite";
    public static final String ISSUER_PHONE = "issuerPhone";
    public static final String ISO_COUNTRY_NAME = "isoCountryName";
    public static final String ISO_COUNTRY_CODE_A2 = "isoCountryCodeA2";
    public static final String ISO_COUNTRY_CODE_A3 = "isoCountryCodeA3";
    public static final String ISO_COUNTRY_CURRENCY = "isoCountryCurrency";

    private BankCardConstants() {
        // Private constructor to prevent instantiation
    }
}