package com.bankcard.security;

public class MaskingUtil {

    private MaskingUtil() {
        // Private constructor to prevent instantiation
    }

    public static String maskCardNumber(String cardNumber) {
        if (cardNumber == null || cardNumber.length() < 4) {
            return cardNumber;
        }
        String lastFourDigits = cardNumber.substring(cardNumber.length() - 4);
        return repeat('*', cardNumber.length() - 4) + lastFourDigits;
    }

    public static String repeat(char ch, int count) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < count; i++) {
            builder.append(ch);
        }
        return builder.toString();
    }

    public static String maskName(String name) {
        if (name == null || name.isEmpty()) {
            return name;
        }
        StringBuilder masked = new StringBuilder();
        String[] parts = name.split("\\s+");
        for (String part : parts) {
            if (part.length() > 1) {
                masked.append(part.charAt(0)).append(repeat('*', part.length() - 1)).append(" ");
            } else {
                masked.append(part).append(" ");
            }
        }
        return masked.toString().trim();
    }
}