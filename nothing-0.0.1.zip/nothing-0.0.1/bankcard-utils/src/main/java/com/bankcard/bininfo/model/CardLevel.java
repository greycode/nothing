package com.bankcard.bininfo;

public enum CardLevel {
    STANDARD, GOLD, PLATINUM, PREMIUM, BUSINESS, CORPORATE, UNKNOWN
}