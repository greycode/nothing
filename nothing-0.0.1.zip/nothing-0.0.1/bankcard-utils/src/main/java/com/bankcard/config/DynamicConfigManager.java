package com.bankcard.config;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.URL;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class DynamicConfigManager {
    private static final DynamicConfigManager INSTANCE = new DynamicConfigManager();
    private final Map<String, Object> configMap = new ConcurrentHashMap<>();
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();

    private DynamicConfigManager() {
        // Private constructor to enforce singleton
    }

    public static DynamicConfigManager getInstance() {
        return INSTANCE;
    }

    public void startConfigUpdateScheduler(String configUrl, long updateIntervalSeconds) {
        scheduler.scheduleAtFixedRate(() -> updateConfig(configUrl), 0, updateIntervalSeconds, TimeUnit.SECONDS);
    }

    private void updateConfig(String configUrl) {
        try {
            JsonNode rootNode = objectMapper.readTree(new URL(configUrl));
            updateConfigMap(rootNode);
        } catch (IOException e) {
            System.err.println("Failed to update config: " + e.getMessage());
        }
    }

    private void updateConfigMap(JsonNode rootNode) {
        rootNode.fields().forEachRemaining(entry -> {
            String key = entry.getKey();
            JsonNode value = entry.getValue();
            if (value.isTextual()) {
                configMap.put(key, value.asText());
            } else if (value.isInt()) {
                configMap.put(key, value.asInt());
            } else if (value.isBoolean()) {
                configMap.put(key, value.asBoolean());
            } else if (value.isDouble()) {
                configMap.put(key, value.asDouble());
            }
            // Add more types as needed
        });
    }

    public String getString(String key, String defaultValue) {
        return (String) configMap.getOrDefault(key, defaultValue);
    }

    public int getInt(String key, int defaultValue) {
        return (int) configMap.getOrDefault(key, defaultValue);
    }

    public boolean getBoolean(String key, boolean defaultValue) {
        return (boolean) configMap.getOrDefault(key, defaultValue);
    }

    public double getDouble(String key, double defaultValue) {
        return (double) configMap.getOrDefault(key, defaultValue);
    }

    public void shutdown() {
        scheduler.shutdown();
    }
}