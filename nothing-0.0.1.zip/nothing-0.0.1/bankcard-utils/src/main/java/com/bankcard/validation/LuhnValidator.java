package com.bankcard.validation;

public class LuhnValidator {

    private LuhnValidator() {
        // Private constructor to prevent instantiation
    }

    public static boolean isValid(String cardNumber) {
        if (cardNumber == null || cardNumber.isEmpty()) {
            return false;
        }

        int sum = 0;
        boolean alternate = false;

        for (int i = cardNumber.length() - 1; i >= 0; i--) {
            int n = Character.digit(cardNumber.charAt(i), 10);
            if (n < 0) {
                return false; // Non-digit character found
            }

            if (alternate) {
                n *= 2;
                if (n > 9) {
                    n = (n % 10) + 1;
                }
            }
            sum += n;
            alternate = !alternate;
        }

        return (sum % 10 == 0);
    }
}