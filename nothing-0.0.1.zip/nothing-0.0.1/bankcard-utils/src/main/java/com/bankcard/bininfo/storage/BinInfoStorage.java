package com.bankcard.bininfo.storage;

import com.bankcard.bininfo.BinInfo;
import java.util.List;

public interface BinInfoStorage {
    void addBinInfo(BinInfo binInfo);
    BinInfo getBinInfo(String bin);
    void updateBinInfo(BinInfo binInfo);
    List<BinInfo> getAllBinInfo();
}